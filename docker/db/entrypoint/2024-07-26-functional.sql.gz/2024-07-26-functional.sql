--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cache; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO "webshop-api";

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO "webshop-api";

--
-- Name: categories; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    parent_id bigint
);


ALTER TABLE public.categories OWNER TO "webshop-api";

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO "webshop-api";

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: category_product; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.category_product (
    id bigint NOT NULL,
    sku character varying(255) NOT NULL,
    category_id bigint NOT NULL
);


ALTER TABLE public.category_product OWNER TO "webshop-api";

--
-- Name: category_product_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.category_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.category_product_id_seq OWNER TO "webshop-api";

--
-- Name: category_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.category_product_id_seq OWNED BY public.category_product.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO "webshop-api";

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO "webshop-api";

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO "webshop-api";

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO "webshop-api";

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO "webshop-api";

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.line_items (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    order_id bigint NOT NULL,
    sku character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    price integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.line_items OWNER TO "webshop-api";

--
-- Name: line_items_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.line_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.line_items_id_seq OWNER TO "webshop-api";

--
-- Name: line_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.line_items_id_seq OWNED BY public.line_items.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO "webshop-api";

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO "webshop-api";

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: modifiers; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.modifiers (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    order_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    amount integer NOT NULL,
    description character varying(255) NOT NULL
);


ALTER TABLE public.modifiers OWNER TO "webshop-api";

--
-- Name: modifiers_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.modifiers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.modifiers_id_seq OWNER TO "webshop-api";

--
-- Name: modifiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.modifiers_id_seq OWNED BY public.modifiers.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.orders (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    address character varying(255) NOT NULL,
    city character varying(255) NOT NULL,
    country character varying(255) NOT NULL,
    subtotal integer NOT NULL,
    total integer NOT NULL
);


ALTER TABLE public.orders OWNER TO "webshop-api";

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO "webshop-api";

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO "webshop-api";

--
-- Name: price_list_product; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.price_list_product (
    id bigint NOT NULL,
    price_list_id bigint NOT NULL,
    sku character varying(255) NOT NULL,
    price integer NOT NULL
);


ALTER TABLE public.price_list_product OWNER TO "webshop-api";

--
-- Name: price_list_product_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.price_list_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.price_list_product_id_seq OWNER TO "webshop-api";

--
-- Name: price_list_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.price_list_product_id_seq OWNED BY public.price_list_product.id;


--
-- Name: price_lists; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.price_lists (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    name character varying(255) NOT NULL
);


ALTER TABLE public.price_lists OWNER TO "webshop-api";

--
-- Name: price_lists_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.price_lists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.price_lists_id_seq OWNER TO "webshop-api";

--
-- Name: price_lists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.price_lists_id_seq OWNED BY public.price_lists.id;


--
-- Name: product_user; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.product_user (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    sku character varying(255) NOT NULL,
    price integer NOT NULL
);


ALTER TABLE public.product_user OWNER TO "webshop-api";

--
-- Name: product_user_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.product_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_user_id_seq OWNER TO "webshop-api";

--
-- Name: product_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.product_user_id_seq OWNED BY public.product_user.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.products (
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    sku character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    price integer NOT NULL,
    published boolean NOT NULL
);


ALTER TABLE public.products OWNER TO "webshop-api";

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO "webshop-api";

--
-- Name: telescope_entries; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.telescope_entries (
    sequence bigint NOT NULL,
    uuid uuid NOT NULL,
    batch_id uuid NOT NULL,
    family_hash character varying(255),
    should_display_on_index boolean DEFAULT true NOT NULL,
    type character varying(20) NOT NULL,
    content text NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.telescope_entries OWNER TO "webshop-api";

--
-- Name: telescope_entries_sequence_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.telescope_entries_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.telescope_entries_sequence_seq OWNER TO "webshop-api";

--
-- Name: telescope_entries_sequence_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.telescope_entries_sequence_seq OWNED BY public.telescope_entries.sequence;


--
-- Name: telescope_entries_tags; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.telescope_entries_tags (
    entry_uuid uuid NOT NULL,
    tag character varying(255) NOT NULL
);


ALTER TABLE public.telescope_entries_tags OWNER TO "webshop-api";

--
-- Name: telescope_monitoring; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.telescope_monitoring (
    tag character varying(255) NOT NULL
);


ALTER TABLE public.telescope_monitoring OWNER TO "webshop-api";

--
-- Name: users; Type: TABLE; Schema: public; Owner: webshop-api
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO "webshop-api";

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: webshop-api
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO "webshop-api";

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: webshop-api
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: category_product id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.category_product ALTER COLUMN id SET DEFAULT nextval('public.category_product_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: line_items id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.line_items ALTER COLUMN id SET DEFAULT nextval('public.line_items_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: modifiers id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.modifiers ALTER COLUMN id SET DEFAULT nextval('public.modifiers_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: price_list_product id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.price_list_product ALTER COLUMN id SET DEFAULT nextval('public.price_list_product_id_seq'::regclass);


--
-- Name: price_lists id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.price_lists ALTER COLUMN id SET DEFAULT nextval('public.price_lists_id_seq'::regclass);


--
-- Name: product_user id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.product_user ALTER COLUMN id SET DEFAULT nextval('public.product_user_id_seq'::regclass);


--
-- Name: telescope_entries sequence; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.telescope_entries ALTER COLUMN sequence SET DEFAULT nextval('public.telescope_entries_sequence_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.categories (id, created_at, updated_at, name, description, parent_id) FROM stdin;
1	2022-01-01 00:00:00	2022-01-01 00:00:00	Computers	Lorem ipsum dolor.	\N
2	2022-01-01 00:00:00	2022-01-01 00:00:00	Laptops	Lorem ipsum dolor.	1
3	2022-01-01 00:00:00	2022-01-01 00:00:00	Keyboards	Lorem ipsum dolor.	1
4	2022-01-01 00:00:00	2022-01-01 00:00:00	Brands	Lorem ipsum dolor.	\N
5	2022-01-01 00:00:00	2022-01-01 00:00:00	Lenovo	Lorem ipsum dolor.	4
6	2022-01-01 00:00:00	2022-01-01 00:00:00	Apple	Lorem ipsum dolor.	4
7	2022-01-01 00:00:00	2022-01-01 00:00:00	Test Category With no Products 1	Lorem ipsum dolor.	\N
8	2022-01-01 00:00:00	2022-01-01 00:00:00	Test Category With no Products 1.1	Lorem ipsum dolor.	7
9	2022-01-01 00:00:00	2022-01-01 00:00:00	Test Category With no Products 1.1.1	Lorem ipsum dolor.	8
\.


--
-- Data for Name: category_product; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.category_product (id, sku, category_id) FROM stdin;
1	SKU-laptop-01	2
2	SKU-laptop-02	2
3	SKU-laptop-03	2
4	SKU-laptop-04	2
5	SKU-laptop-05	2
6	SKU-laptop-06	2
7	SKU-laptop-07	2
8	SKU-laptop-08	2
9	SKU-laptop-09	2
10	SKU-laptop-10	2
11	SKU-laptop-11	2
12	SKU-laptop-11	6
13	SKU-laptop-12	2
14	SKU-laptop-12	6
15	SKU-laptop-13	2
16	SKU-laptop-14	2
17	SKU-laptop-15	2
18	SKU-laptop-16	2
19	SKU-laptop-17	2
20	SKU-laptop-18	2
21	SKU-laptop-19	2
22	SKU-laptop-20	2
23	SKU-laptop-21	2
24	SKU-laptop-22	2
25	SKU-laptop-23	2
26	SKU-laptop-24	2
27	SKU-laptop-25	2
28	SKU-keyboard-01	3
29	SKU-keyboard-02	3
30	SKU-keyboard-03	3
31	SKU-keyboard-04	3
32	SKU-keyboard-05	3
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.line_items (id, created_at, updated_at, order_id, sku, name, price, quantity) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2024_07_20_113052_create_products_table	1
5	2024_07_20_121911_create_categories_table	1
6	2024_07_21_170123_create_orders_table	1
7	2024_07_21_190448_create_category_product_table	1
8	2024_07_22_060314_create_telescope_entries_table	1
9	2024_07_22_091407_create_price_lists_table	1
10	2024_07_22_115534_create_price_list_product_table	1
11	2024_07_23_181234_create_product_user_table	1
12	2024_07_25_205217_create_line_items_table	1
13	2024_07_26_072113_create_modifiers_table	1
\.


--
-- Data for Name: modifiers; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.modifiers (id, created_at, updated_at, order_id, name, amount, description) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.orders (id, created_at, updated_at, first_name, last_name, email, phone, address, city, country, subtotal, total) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: price_list_product; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.price_list_product (id, price_list_id, sku, price) FROM stdin;
1	1	SKU-laptop-01	45000
2	1	SKU-laptop-02	49500
3	1	SKU-laptop-11	101000
4	1	SKU-laptop-12	102000
\.


--
-- Data for Name: price_lists; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.price_lists (id, created_at, updated_at, name) FROM stdin;
1	2022-01-01 00:00:00	2022-01-01 00:00:00	Partner Computer Service Shop 01
2	2022-01-01 00:00:00	2022-01-01 00:00:00	Test Empty Price List
\.


--
-- Data for Name: product_user; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.product_user (id, user_id, sku, price) FROM stdin;
1	1	SKU-laptop-01	40000
2	1	SKU-laptop-02	44000
3	1	SKU-laptop-11	105000
4	1	SKU-laptop-12	106000
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.products (created_at, updated_at, sku, name, description, price, published) FROM stdin;
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-01	Laptop 01	Description 01.	50000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-02	Laptop 02	Description 02.	100000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-03	Laptop 03	Description 03.	150000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-04	Laptop 04	Description 04.	200000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-05	Laptop 05	Description 05.	250000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-06	Laptop 06	Description 06.	300000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-07	Laptop 07	Description 07.	350000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-08	Laptop 08	Description 08.	400000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-09	Laptop 09	Description 09.	450000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-10	Laptop 10	Description 10.	500000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-11	Laptop 11	Description 11.	550000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-12	Laptop 12	Description 12.	600000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-13	Laptop 13	Description 13.	650000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-14	Laptop 14	Description 14.	700000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-15	Laptop 15	Description 15.	750000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-16	Laptop 16	Description 16.	800000	f
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-17	Laptop 17	Description 17.	850000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-18	Laptop 18	Description 18.	900000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-19	Laptop 19	Description 19.	950000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-20	Laptop 20	Description 20.	1000000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-21	Laptop 21	Description 21.	1050000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-22	Laptop 22	Description 22.	1100000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-23	Laptop 23	Description 23.	1150000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-24	Laptop 24	Description 24.	1200000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-laptop-25	Laptop 25	Description 25.	1250000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-keyboard-01	Keyboard 01	Description 01.	1000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-keyboard-02	Keyboard 02	Description 02.	2000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-keyboard-03	Keyboard 03	Description 03.	3000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-keyboard-04	Keyboard 04	Description 04.	4000	t
2022-01-01 00:00:00	2022-01-01 00:00:00	SKU-keyboard-05	Keyboard 05	Description 05.	5000	t
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: telescope_entries; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.telescope_entries (sequence, uuid, batch_id, family_hash, should_display_on_index, type, content, created_at) FROM stdin;
\.


--
-- Data for Name: telescope_entries_tags; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.telescope_entries_tags (entry_uuid, tag) FROM stdin;
\.


--
-- Data for Name: telescope_monitoring; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.telescope_monitoring (tag) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: webshop-api
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
1	John Doe 01	john-doe-01@example.com	2022-01-01 00:00:00	$2y$12$oiAuvDGtC77xvZUfbnnu1Ogh9dl6kKei1SHVaPnMvYhnBdI/snL9.	7Yh0WzaNwA	2022-01-01 00:00:00	2022-01-01 00:00:00
2	John Doe 02	john-doe-02@example.com	2022-01-01 00:00:00	$2y$12$/wtNsUjwtU.0CyyTQmFmH.X/iodlwVab9gsXoEQ6HvcwZXApt6BdS	FdLW5Cmnmz	2022-01-01 00:00:00	2022-01-01 00:00:00
3	John Doe 03	john-doe-03@example.com	2022-01-01 00:00:00	$2y$12$o8EA.lom8PSBWO1UUwqlhu4h69/sp.TuG7eJha8v/QqTC4.RYHASO	JttU1EmVMt	2022-01-01 00:00:00	2022-01-01 00:00:00
4	John Doe 04	john-doe-04@example.com	2022-01-01 00:00:00	$2y$12$sJiXTsGMv0mlobdDm/.ARuCk5ShOgeadlJguxmXSm90.xkHiryQo6	ZcFB8sxIox	2022-01-01 00:00:00	2022-01-01 00:00:00
5	John Doe 05	john-doe-05@example.com	2022-01-01 00:00:00	$2y$12$PyC1.SvJ5Uk03ol.LmAXfuxh11oQ0xfdCtfSEmm.RQrREym9pD1Re	vSAG4ECy1A	2022-01-01 00:00:00	2022-01-01 00:00:00
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.categories_id_seq', 9, true);


--
-- Name: category_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.category_product_id_seq', 32, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: line_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.line_items_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.migrations_id_seq', 13, true);


--
-- Name: modifiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.modifiers_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: price_list_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.price_list_product_id_seq', 4, true);


--
-- Name: price_lists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.price_lists_id_seq', 2, true);


--
-- Name: product_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.product_user_id_seq', 4, true);


--
-- Name: telescope_entries_sequence_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.telescope_entries_sequence_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: webshop-api
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_product category_product_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.category_product
    ADD CONSTRAINT category_product_pkey PRIMARY KEY (id);


--
-- Name: category_product category_product_sku_category_id_unique; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.category_product
    ADD CONSTRAINT category_product_sku_category_id_unique UNIQUE (sku, category_id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: line_items line_items_id_sku_unique; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_id_sku_unique UNIQUE (id, sku);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: modifiers modifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: price_list_product price_list_product_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.price_list_product
    ADD CONSTRAINT price_list_product_pkey PRIMARY KEY (id);


--
-- Name: price_list_product price_list_product_price_list_id_sku_unique; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.price_list_product
    ADD CONSTRAINT price_list_product_price_list_id_sku_unique UNIQUE (price_list_id, sku);


--
-- Name: price_lists price_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.price_lists
    ADD CONSTRAINT price_lists_pkey PRIMARY KEY (id);


--
-- Name: product_user product_user_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.product_user
    ADD CONSTRAINT product_user_pkey PRIMARY KEY (id);


--
-- Name: product_user product_user_user_id_sku_unique; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.product_user
    ADD CONSTRAINT product_user_user_id_sku_unique UNIQUE (user_id, sku);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (sku);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: telescope_entries telescope_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.telescope_entries
    ADD CONSTRAINT telescope_entries_pkey PRIMARY KEY (sequence);


--
-- Name: telescope_entries_tags telescope_entries_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.telescope_entries_tags
    ADD CONSTRAINT telescope_entries_tags_pkey PRIMARY KEY (entry_uuid, tag);


--
-- Name: telescope_entries telescope_entries_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.telescope_entries
    ADD CONSTRAINT telescope_entries_uuid_unique UNIQUE (uuid);


--
-- Name: telescope_monitoring telescope_monitoring_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.telescope_monitoring
    ADD CONSTRAINT telescope_monitoring_pkey PRIMARY KEY (tag);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: price_list_product_price_list_id_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX price_list_product_price_list_id_index ON public.price_list_product USING btree (price_list_id);


--
-- Name: price_list_product_sku_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX price_list_product_sku_index ON public.price_list_product USING btree (sku);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: telescope_entries_batch_id_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX telescope_entries_batch_id_index ON public.telescope_entries USING btree (batch_id);


--
-- Name: telescope_entries_created_at_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX telescope_entries_created_at_index ON public.telescope_entries USING btree (created_at);


--
-- Name: telescope_entries_family_hash_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX telescope_entries_family_hash_index ON public.telescope_entries USING btree (family_hash);


--
-- Name: telescope_entries_tags_tag_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX telescope_entries_tags_tag_index ON public.telescope_entries_tags USING btree (tag);


--
-- Name: telescope_entries_type_should_display_on_index_index; Type: INDEX; Schema: public; Owner: webshop-api
--

CREATE INDEX telescope_entries_type_should_display_on_index_index ON public.telescope_entries USING btree (type, should_display_on_index);


--
-- Name: category_product category_product_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.category_product
    ADD CONSTRAINT category_product_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: category_product category_product_sku_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.category_product
    ADD CONSTRAINT category_product_sku_foreign FOREIGN KEY (sku) REFERENCES public.products(sku);


--
-- Name: line_items line_items_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: line_items line_items_sku_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_sku_foreign FOREIGN KEY (sku) REFERENCES public.products(sku);


--
-- Name: modifiers modifiers_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.modifiers
    ADD CONSTRAINT modifiers_order_id_foreign FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: price_list_product price_list_product_price_list_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.price_list_product
    ADD CONSTRAINT price_list_product_price_list_id_foreign FOREIGN KEY (price_list_id) REFERENCES public.price_lists(id);


--
-- Name: price_list_product price_list_product_sku_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.price_list_product
    ADD CONSTRAINT price_list_product_sku_foreign FOREIGN KEY (sku) REFERENCES public.products(sku);


--
-- Name: product_user product_user_sku_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.product_user
    ADD CONSTRAINT product_user_sku_foreign FOREIGN KEY (sku) REFERENCES public.products(sku);


--
-- Name: product_user product_user_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.product_user
    ADD CONSTRAINT product_user_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: telescope_entries_tags telescope_entries_tags_entry_uuid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: webshop-api
--

ALTER TABLE ONLY public.telescope_entries_tags
    ADD CONSTRAINT telescope_entries_tags_entry_uuid_foreign FOREIGN KEY (entry_uuid) REFERENCES public.telescope_entries(uuid) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

